#ifndef LCGPARKMILLER_H
#define LCGPARKMILLER_H

unsigned lcg_parkmiller(unsigned *state);
unsigned next_random();
unsigned random_at_most(unsigned max);

#endif