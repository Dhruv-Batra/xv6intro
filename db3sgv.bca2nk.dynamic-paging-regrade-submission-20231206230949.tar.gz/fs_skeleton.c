#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <assert.h>
#include "inode.h"

#define TOTAL_BLOCKS (10*1024)

static unsigned char rawdata[TOTAL_BLOCKS*BLOCK_SZ];
static char bitmap[TOTAL_BLOCKS];


int get_free_block()
{
  for (int i = 0; i < TOTAL_BLOCKS; i++){
    if (bitmap[i] == '0'){
      bitmap[i] = '1';
      return i;
    }
  }
  perror("Sadge No Blocks Available");
  exit(1);
}

void write_int(int pos, int val)
{
  int *ptr = (int *)&rawdata[pos];
  *ptr = val;
}

FILE extract_file(int t_uid, int t_gid, char* path, int m){
  FILE *extracted_file = fopen(path, "r");  
  //for (struct inode *ip: rawdata){
  for(int i=0; i<m*BLOCK_SZ-sizeof(struct inode);i+=sizeof(struct inode)){
    struct inode* ip;
    if (ip->uid == t_uid && ip->gid == t_gid){
        //for(int blocknum : ip->dblocks){
        fwrite(rawdata, N_DBLOCKS*BLOCK_SZ, 1, extracted_file);
    }
  }     
  fclose(extracted_file);                                                     
}

// FILE extract_bitmap(){
//   FILE *extracted_bm = fopen(path+"UNUSED_BLOCKS", "r");
//   for (struct inode *ip: rawdata){
//     for(int blocknum : ip->dblocks){
//       if(ip->dblocks[i]!=nullptr){
//         bitmap[i]='1'
//       }
//     }
//   }     
//   fclose(file);                                                     
// }

//TODO: insert inode parameter  
void place_file(char *file, int uid, int gid, struct inode* ip)
{
  int nbytes = 0;
  int i = 0;
  int i2block_index, i3block_index;
  FILE *fpr;
  unsigned char buf[BLOCK_SZ];

  ip->mode = 0;
  ip->nlink = 1;
  ip->uid = uid;
  ip->gid = gid;
  ip->ctime = random();
  ip->mtime = random();
  ip->atime = random();

  fpr = fopen(file, "rb");
  if (!fpr) {
    perror(file);
    exit(-1);
  }
  int a = 0;
  while ((nbytes = fread(buf, 1024, BLOCK_SZ,fpr)) > 0){
    int blockno = get_free_block();
    memcpy(&rawdata[blockno * BLOCK_SZ], buf, nbytes);
    ip->dblocks[a] = blockno;
    a++;
  }

  // fill in here if IBLOCKS needed
  // if so, you will first need to get an empty block to use for your IBLOCK

  ip->size = ftell(fpr);  // total number of data bytes written for file
  fclose(fpr);
  printf("successfully wrote %d bytes of file %s\n", ip->size, file);
}

/* disk_image -create -image IMAGE_FILE -nblocks N -iblocks M -inputfile 
FILE -u UID -g GID -block D -inodepos I */
/* in: IMAGE_FILE:string > N:int > M:int > FILE:string > UID:int > GID:int > D:int > I:int*/
void main(int argc, char* argv[]) // add argument handling
{
  char* image_file = "";
  char* input_file = "";
  char* path = "";
  int n = 0;
  int m = 0;
  int uid = 0;
  int gid = 0;
  int blockno = 0;
  int inodepos = 0;
  int isCreate = 0;
  int isInsert = 0;
  int isExtract = 0;

  for (int i = 0; i < argc; i++){
    if (strcmp(argv[i], "-create") == 0){
        isCreate = 1;
    }
    else if (strcmp(argv[i], "-insert") == 0){
        isInsert = 1;
    }
    else if (strcmp(argv[i], "-extract") == 0){
        isExtract = 1;
    }
    else if (strcmp(argv[i], "-image") == 0){
        image_file = argv[i+1];
    }
    else if (strcmp(argv[i], "-inputfile") == 0){
        input_file = argv[i+1];
    }
    else if (strcmp(argv[i], "-nblocks") == 0){
        n = atoi(argv[i+1]);
    }
    else if (strcmp(argv[i], "-iblocks") == 0 ){
        m = atoi(argv[i+1]);
    }
    else if (strcmp(argv[i],"-u") == 0){
        uid = atoi(argv[i+1]);
    }
    else if (strcmp(argv[i], "-g") == 0){
        gid = atoi(argv[i+1]);
    }
    else if (strcmp(argv[i], "-block") == 0){
        blockno = atoi(argv[i+1]);
    }
    else if (strcmp(argv[i], "-inodepos")){
        inodepos = atoi(argv[i+1]);
    }
    else if (strcmp(argv[i], "-o")){
        path = argv[i+1];
    }
  }

  // cprintf("INODE " +to_string(sizeof(inode)));
  int i, place_index;
  char *outfile;
  
  //Bounds Checking
  //check M < N bounds of inode blocks should be within total amount of blocks
  //check D < M block D within inode for source block should be within block range for inodes
  //check if sizeof(inode) within bounds of bytes for inode range
  if(m>n ||  blockno>m || sizeof(struct inode)>BLOCK_SZ*m){
    perror("arguments not valid, does not follow expected relationships");
    exit(-1);
  }
  char* output_filename = "output";
  outfile = fopen(output_filename, "wb");
  if (!outfile) {
    perror("datafile open");
    exit(-1);
  }

  place_index = blockno*BLOCK_SZ + inodepos*sizeof(struct inode);

  if (isInsert){
      if(strlen(image_file) < TOTAL_BLOCKS*BLOCK_SZ) //rawdata len
        strcpy((char*) rawdata, image_file);
      else{
        perror("file larger then availiable disk image size");
        exit(-1);
      }
      //check if inode at place_index is occupied
      struct inode* check = (struct inode*)(place_index);
      if(check->size==0){
        place_file(input_file, uid, gid, check);
      }else{
        perror("Inode Position Specified is Already Populated");
        exit(-1);
      }
  }else if (isCreate){
    //zero out raw data
    memset(rawdata, 0, sizeof(rawdata));
    //iterate through each block dedicated for inodes
    for(int i=0; i<m; i++){
      //turn the space available into inode objects
      struct inode *template;
      unsigned char temp[sizeof(struct inode)];
      for(int j=0; j<(BLOCK_SZ-sizeof(struct inode));j+=sizeof(struct inode)){
          memcpy(temp, template, sizeof(struct inode));
          rawdata[BLOCK_SZ*blockno+j] = temp;
      }

    }
    struct inode* check = (struct inode*)(place_index);
    if(check->size==0){
      place_file(input_file, uid, gid, check);
    }else{
      perror("Inode Position Specified is Already Populated");
      exit(-1);
    }
  } else if (isExtract){
    // extract_bitmap();
    //extract file by uid and gid
    extract_file(uid, gid,path,m);
  }
  
  

  i = fwrite(rawdata, 1, TOTAL_BLOCKS*BLOCK_SZ, outfile);
  if (i != TOTAL_BLOCKS*BLOCK_SZ) {
    perror("fwrite");
    exit(-1);
  }

  i = fclose(outfile);
  if (i) {
    perror("datafile close");
    exit(-1);
  }

  printf("Done.\n");
  return;
}